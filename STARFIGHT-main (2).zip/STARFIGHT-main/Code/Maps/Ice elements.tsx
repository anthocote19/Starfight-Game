<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Ice elements" tilewidth="16" tileheight="16" tilecount="132" columns="12">
 <image source="../Sprites/kenney_tiny-ski/Tilemap/tilemap_packed.png" width="192" height="176"/>
</tileset>
