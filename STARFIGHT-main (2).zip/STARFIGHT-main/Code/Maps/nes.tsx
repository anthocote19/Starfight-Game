<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="bird" tilewidth="17" tileheight="17" tilecount="1760" columns="40">
 <image source="NES - Super Mario Bros - Tileset.png" width="680" height="764"/>
</tileset>
